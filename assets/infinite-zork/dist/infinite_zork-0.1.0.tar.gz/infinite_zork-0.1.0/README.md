# infinite-zork
An LLM-generated text adventure.
