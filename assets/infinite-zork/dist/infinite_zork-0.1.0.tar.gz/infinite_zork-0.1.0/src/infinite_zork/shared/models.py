import uuid
from enum import StrEnum, auto
from typing import Any, Literal

from pydantic import BaseModel, Field


Position: type = tuple[int, int]


class Thing(BaseModel):
    """Base class for all game objects"""

    id: uuid.UUID = Field(default_factory=uuid.uuid4)


class CardinalDirection(StrEnum):
    NORTH = "north"
    SOUTH = "south"
    EAST = "east"
    WEST = "west"


class Exit(BaseModel):
    location: tuple[int, int]
    direction: str
    description: str
    room_id: uuid.UUID
    allowed: bool = True


class OutcomeType(StrEnum):
    set_flag = "SetFlag"
    create_item = "CreateItem"
    change_desc = "ChangeDesc"


class Outcome(BaseModel):
    type: OutcomeType
    args: tuple[Any, ...]


class Action(BaseModel):
    syntax: str
    outcome: Outcome


class Physical(Thing):
    short_name: str
    description: str
    aliases: list[str] = []

    @property
    def name_as_id(self):
        return self.short_name.lower().replace(" ", "_")


class Fixture(Physical):
    container: bool


class Item(Physical):
    is_treasure: bool = False


class RoomItemPlacement(Thing):
    item_id: uuid.UUID
    description: str = Field(
        description="Description of the item in its original location before being picked up."
    )
    location: Literal["room"] | uuid.UUID = Field(
        description="Item's location. 'Room' if in the room, or fixture ID if in a container fixture."
    )


class RoomType(StrEnum):
    ATMOSPHERIC = auto()  # Adds flavor but has minimal interaction
    PUZZLE = auto()  # Contains a puzzle with a reward
    TREASURE = auto()  # Contains valuable items with no/minimal puzzle
    START = auto()  # Beginning location for the player


class ProcGenMetadata(BaseModel):
    """Metadata for procedural generation"""

    num_treasures: int = 0
    num_functional_items: int = 0
    num_puzzles: int = 0
    room_type: RoomType
    tags: list[str]


class Room(Thing):
    title: str
    base_description: str
    item_placements: list[RoomItemPlacement] = Field(default_factory=list)
    fixtures: list[Fixture] = Field(default_factory=list)
    actions: list[Action] = Field(default_factory=list)
    flags: set[str] = Field(default_factory=set)
    exit_map: dict[str, Exit] = Field(default_factory=dict)
    metadata: ProcGenMetadata = Field(default_factory=dict)
    position: Position

    @property
    def description(self) -> str:
        """Combines base description with any dynamic elements"""
        return self.base_description  # This can be expanded later

    @property
    def exits(self) -> list[Exit]:
        return list(self.exit_map.values())

    @property
    def has_containers(self) -> bool:
        return any(f.container for f in self.fixtures)


class Player(Thing):
    score: int = 0
    current_room_id: uuid.UUID
    inventory: list[Item] = Field(default_factory=list)


class GameState(BaseModel):
    """Root container for the entire game state"""

    player: Player | None = None
    rooms: dict[uuid.UUID, Room] = Field(default_factory=dict)
    items: dict[uuid.UUID, Item] = Field(default_factory=dict)

    start_room_id: uuid.UUID | None = None

    @property
    def ready(self):
        return self.player is not None and self.start_room_id is not None

    @property
    def interactable_objects(self):
        if not self.ready:
            raise ValueError("Game is not ready yet")

        room = self.rooms[self.player.current_room_id]

        items = [self.items[i.item_id] for i in room.item_placements]

        return items + room.fixtures


# === Procgen ===


class PuzzleBlock(StrEnum):
    action_on_fixture = auto()
    item_on_fixture = auto()


class Puzzle(BaseModel):
    """
    A stub for puzzles that will be expanded later.
    Used for procedural generation.
    """

    steps: list[PuzzleBlock] = Field(default_factory=list)


type NotReady = None


class ExitStub(BaseModel):
    location: tuple[int, int]
    direction: str
    allowed: bool = True
    room_id: uuid.UUID


class RoomStub(BaseModel):
    """
    Minimal representation of a room used for procedural generation.
    Contains just enough information to generate the initial layout.
    """

    id: uuid.UUID = Field(default_factory=uuid.uuid4)
    tags: tuple[str, ...]
    room_type: str
    exits: list[ExitStub] | NotReady = Field(default=NotReady)
    puzzles: list[Puzzle] = Field(default_factory=list)
    num_treasures: int = 0
    num_functional_items: int = 0
    position: Position

    @property
    def num_items(self) -> int:
        return self.num_treasures + self.num_functional_items

    def ready(self) -> bool:
        """
        Check if the RoomStub has all necessary parameters set
        to be transformed into a full Room.
        """
        return isinstance(self.exits, list)


# Game Engine/Parser


class GameInput(BaseModel):
    text: str


class GameOutput(BaseModel):
    text: str


class StateChange(BaseModel):
    text: str
