import uuid
from enum import StrEnum, auto
from functools import cached_property
from typing import Any, Literal

from pydantic import BaseModel, Field


type Position = tuple[int, int]


class Thing(BaseModel):
    """Base class for all game objects"""

    id: uuid.UUID = Field(default_factory=uuid.uuid4)


class CardinalDirection(StrEnum):
    NORTH = "north"
    SOUTH = "south"
    EAST = "east"
    WEST = "west"


class Exit(BaseModel):
    location: tuple[int, int]
    direction: str
    description: str
    room_id: uuid.UUID
    allowed: bool = True


class OutcomeType(StrEnum):
    set_flag = "SetFlag"
    create_item = "CreateItem"
    change_desc = "ChangeDesc"


class Outcome(BaseModel):
    type: OutcomeType
    args: tuple[Any, ...]


class Action(BaseModel):
    syntax: str
    outcome: Outcome


class Physical(Thing):
    short_name: str
    description: str
    aliases: list[str] = []

    @property
    def name_as_id(self):
        return self.short_name.lower().replace(" ", "_")

    def __hash__(self):
        return hash(self.name_as_id + self.description)


class Fixture(Physical):
    container: bool
    level: int = 0


class Decorative(Physical):
    pass


class Item(Physical):
    is_treasure: bool = False
    found: bool = False

    @property
    def score(self) -> int:
        return 10 if self.is_treasure else 0


class RoomItemPlacement(Thing):
    item_id: uuid.UUID
    description: str = Field(
        description="Description of the item in its original location before being picked up."
    )
    location: Literal["room"] | uuid.UUID = Field(
        description="Item's location. 'Room' if in the room, or fixture ID if in a container fixture."
    )


class RoomType(StrEnum):
    ATMOSPHERIC = auto()  # Adds flavor but has minimal interaction
    PUZZLE = auto()  # Contains a puzzle with a reward
    TREASURE = auto()  # Contains valuable items with no/minimal puzzle
    START = auto()  # Beginning location for the player


class ProcGenMetadata(BaseModel):
    """Metadata for procedural generation"""

    num_treasures: int = 0
    num_functional_items: int = 0
    num_puzzles: int = 0
    room_type: RoomType
    tags: list[str]


class Room(Thing):
    title: str
    base_description: str
    item_placements: list[RoomItemPlacement] = Field(default_factory=list)
    fixtures: list[Fixture] = Field(default_factory=list)
    decoratives: list[Decorative] = Field(default_factory=list)
    actions: list[Action] = Field(default_factory=list)
    flags: set[str] = Field(default_factory=set)
    exit_map: dict[str, Exit] = Field(default_factory=dict)
    metadata: ProcGenMetadata
    position: Position

    @property
    def description(self) -> str:
        """Combines base description with any dynamic elements"""
        return self.base_description  # This can be expanded later

    @property
    def exits(self) -> list[Exit]:
        return list(self.exit_map.values())

    @property
    def has_containers(self) -> bool:
        return any(f.container for f in self.fixtures)


class Player(Thing):
    score: int = 0
    current_room_id: uuid.UUID
    inventory: list[Item] = Field(default_factory=list)
    num_moves: int = 0

    def get_item(self, id: str) -> Item:
        try:
            return [r for r in self.inventory if r.id == id][0]
        except IndexError:
            return None


class GameState(BaseModel):
    """Root container for the entire game state"""

    player: Player | None = None
    rooms: dict[uuid.UUID, Room] = Field(default_factory=dict)
    items: dict[uuid.UUID, Item] = Field(default_factory=dict)

    start_room_id: uuid.UUID | None = None

    game_won: bool = False

    @property
    def ready(self):
        return self.player is not None and self.start_room_id is not None

    @property
    def interactable_objects(self):
        if not self.ready:
            raise ValueError("Game is not ready yet")

        room = self.rooms[self.player.current_room_id]

        items = [self.items[i.item_id] for i in room.item_placements]

        return items + room.fixtures

    @cached_property
    def map_nodes(self) -> set[Position]:
        """
        Get all room positions as a set of coordinates.
        Cached since the map is static once created.
        """
        return {room.position for room in self.rooms.values()}

    @cached_property
    def map_edges(self) -> set[tuple[Position, Position]]:
        """
        Get all connections between rooms as a set of edge tuples.
        Each edge is represented as ((x1, y1), (x2, y2)).
        Cached since the map is static once created.
        """
        edges = set()
        for room in self.rooms.values():
            for exit in room.exits:
                if exit.allowed:
                    # Create edge from current room to connected room
                    edge = (room.position, exit.location)
                    # Normalize edge ordering to avoid duplicates in undirected graph
                    edges.add(tuple(sorted([edge[0], edge[1]])))
        return edges

    @property
    def stats(self):
        return {
            "num_items": len(self.items),
            "num_rooms": len(self.rooms),
            "num_fixtures": sum(len(r.fixtures) for r in self.rooms.values()),
        }

    @property
    def max_score(self):
        """We calculate score based on items for now."""
        return sum(item.score for item in self.items.values())


# === Procgen ===


class PuzzleBlock(StrEnum):
    action_on_fixture = auto()
    item_on_fixture = auto()


class Puzzle(BaseModel):
    """
    A stub for puzzles that will be expanded later.
    Used for procedural generation.
    """

    steps: list[PuzzleBlock] = Field(default_factory=list)


NotReady = None


class ExitStub(BaseModel):
    location: tuple[int, int]
    direction: str
    allowed: bool = True
    room_id: uuid.UUID


class RoomStub(BaseModel):
    """
    Minimal representation of a room used for procedural generation.
    Contains just enough information to generate the initial layout.
    """

    id: uuid.UUID = Field(default_factory=uuid.uuid4)
    tags: tuple[str, ...]
    room_type: str
    exits: list[ExitStub] | None = Field(default=NotReady)
    puzzles: list[Puzzle] = Field(default_factory=list)
    num_treasures: int = 0
    num_functional_items: int = 0
    position: Position

    @property
    def num_items(self) -> int:
        return self.num_treasures + self.num_functional_items

    def ready(self) -> bool:
        """
        Check if the RoomStub has all necessary parameters set
        to be transformed into a full Room.
        """
        return isinstance(self.exits, list)


# Game Engine/Parser


class GameInput(BaseModel):
    text: str


class GameOutput(BaseModel):
    text: str
    minimap: str = ""


class StateChange(BaseModel):
    text: str
