import html

from infinite_zork.shared.models import Position


def draw_minimap(
    coordinates: set[Position],
    edges: set[tuple[Position, Position]],
    current_location: Position,
    radius: int,
) -> str:
    """
    Draw an ASCII minimap centered on the player's current location.

    Args:
        coordinates: Set of (x, y) coordinate tuples representing room positions
        edges: Set of edge tuples, where each edge is ((x1, y1), (x2, y2))
        current_location: The player's current position (x, y)
        radius: Maximum distance from current location to display (square radius)

    Returns:
        ASCII string representation of the minimap with rooms and edges
        @ for current location, # for other rooms, | for vertical edges, -- for horizontal edges
    """
    if not coordinates:
        return "Empty layout"

    # Grid cell dimensions
    CELL_WIDTH = 3  # Characters per cell horizontally
    CELL_HEIGHT = 2  # Lines per cell vertically
    ROOM_OFFSET_X = 1  # Center position within cell horizontally
    ROOM_OFFSET_Y = 0  # Top position within cell vertically

    cx, cy = current_location

    # Calculate the bounds of the minimap based on radius
    min_x = cx - radius
    max_x = cx + radius
    min_y = cy - radius
    max_y = cy + radius

    # Filter coordinates to only those within the radius
    visible_coords = {
        (x, y) for x, y in coordinates if min_x <= x <= max_x and min_y <= y <= max_y
    }

    if not visible_coords:
        return "No rooms in range"

    # Filter to only show nodes connected to the player within the visible area
    # Build adjacency list from visible edges
    adjacency = _make_adjacency_map(edges, visible_coords)

    # BFS from current location to find all reachable nodes
    reachable = _find_reachable_nodes(current_location, visible_coords, adjacency)

    # Only show reachable coordinates
    visible_coords = reachable

    if not visible_coords:
        return "No connected rooms in range"

    # Calculate grid dimensions
    width = (max_x - min_x + 1) * CELL_WIDTH
    height = (max_y - min_y + 1) * CELL_HEIGHT

    # Create a 2D grid to draw on
    grid = [[" " for _ in range(width)] for _ in range(height)]

    def coord_to_grid(x, y):
        """Convert coordinate to grid position (row, col) - returns top-left of cell"""
        # Invert y-axis for traditional layout (higher y = higher on screen)
        grid_y = (max_y - y) * CELL_HEIGHT
        grid_x = (x - min_x) * CELL_WIDTH
        return grid_y, grid_x

    # Draw rooms (centered in their cells)
    for x, y in visible_coords:
        row, col = coord_to_grid(x, y)
        if (x, y) == current_location:
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X] = "@"
        else:
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X] = "#"

    # Convert edges set to a more workable format (handle undirected edges)
    edge_pairs = set()
    for edge in edges:
        pos1, pos2 = edge
        # Normalize edge direction (both orderings represent same undirected edge)
        edge_pairs.add((pos1, pos2))
        edge_pairs.add((pos2, pos1))

    # Draw edges (only those where both endpoints are visible and reachable)
    for from_pos, to_pos in edge_pairs:
        # Skip if either endpoint is not visible or not reachable
        if from_pos not in visible_coords or to_pos not in visible_coords:
            continue

        from_x, from_y = from_pos
        to_x, to_y = to_pos

        # Determine edge direction
        if to_x == from_x + 1 and to_y == from_y:  # East
            row, col = coord_to_grid(from_x, from_y)
            # Draw horizontal line from room center to next room
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X + 1] = "-"
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X + 2] = "-"
        elif to_x == from_x - 1 and to_y == from_y:  # West
            row, col = coord_to_grid(from_x, from_y)
            # Draw horizontal line from room center to previous room
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X - 1] = "-"
            grid[row + ROOM_OFFSET_Y][col + ROOM_OFFSET_X - 2] = "-"
        elif to_y == from_y + 1 and to_x == from_x:  # North
            row, col = coord_to_grid(from_x, from_y)
            # Draw vertical line upward from room center
            if row > 0:
                grid[row - 1][col + ROOM_OFFSET_X] = "|"
        elif to_y == from_y - 1 and to_x == from_x:  # South
            row, col = coord_to_grid(from_x, from_y)
            # Draw vertical line downward from room center
            if row + ROOM_OFFSET_Y + 1 < height:
                grid[row + ROOM_OFFSET_Y + 1][col + ROOM_OFFSET_X] = "|"

    # Convert grid to string
    rows = ["".join(row) for row in grid]
    if rows[-1].strip() == "":
        rows.pop()
    if rows[0].strip() == "":
        rows = rows[1:]
    return "\n".join(rows)


def _find_reachable_nodes(current_node, nodes, adjacency):
    reachable = set()
    if current_node in nodes:
        queue = [current_node]
        reachable.add(current_node)

        while queue:
            current = queue.pop(0)
            if current in adjacency:
                for neighbor in adjacency[current]:
                    if neighbor not in reachable:
                        reachable.add(neighbor)
                        queue.append(neighbor)
    return reachable


def _make_adjacency_map(
    edges: set[tuple[Position, Position]], nodes: set[Position]
) -> dict[Position, Position]:
    adjacency = {}
    for edge in edges:
        pos1, pos2 = edge
        # Only consider edges where both endpoints are visible
        if pos1 in nodes and pos2 in nodes:
            if pos1 not in adjacency:
                adjacency[pos1] = set()
            if pos2 not in adjacency:
                adjacency[pos2] = set()
            adjacency[pos1].add(pos2)
            adjacency[pos2].add(pos1)
    return adjacency


def draw_minimap_html(
    coordinates: set[Position],
    edges: set[tuple[Position, Position]],
    current_location: Position,
    radius: int,
) -> str:
    """
    Return an HTML/Markdown-friendly rendering of the minimap
    with the player position (@) highlighted in yellow.
    """
    ascii_map = draw_minimap(coordinates, edges, current_location, radius)
    escaped = html.escape(ascii_map)
    highlighted = escaped.replace(
        "@", '<span style="color: yellow; font-weight: bold;">@</span>'
    )
    return f'<pre class="minimap">{highlighted}</pre>'


if __name__ == "__main__":
    from infinite_zork.engine.game import initialize

    state = initialize(".output/full_map.json")
    nodes = state.map_nodes
    edges = state.map_edges
    print(draw_minimap(nodes, edges, (0, 0), 2))
    print(draw_minimap(nodes, edges, (0, 0), 10))
