from infinite_zork.shared.models import CardinalDirection


def get_cardinal_direction(point1, point2):
    """
    Given two (x,y) tuples, returns the cardinal direction from point1 to point2
    if the manhattan distance is 1. Otherwise returns None.

    Args:
        point1 (tuple): The starting point as (x,y)
        point2 (tuple): The ending point as (x,y)

    Returns:
        str or None: The cardinal direction ('N', 'E', 'S', 'W') or None if distance is not 1
    """
    x1, y1 = point1
    x2, y2 = point2

    # Calculate Manhattan distance
    distance = abs(x2 - x1) + abs(y2 - y1)

    if distance != 1:
        raise ValueError("Distance must be 1")

    # Determine the direction
    if x2 > x1:
        return CardinalDirection.EAST
    elif x2 < x1:
        return CardinalDirection.WEST
    elif y2 > y1:
        return CardinalDirection.NORTH
    elif y2 < y1:
        return CardinalDirection.SOUTH

    # This should never happen if distance is 1
    raise ValueError("Invalid direction")
