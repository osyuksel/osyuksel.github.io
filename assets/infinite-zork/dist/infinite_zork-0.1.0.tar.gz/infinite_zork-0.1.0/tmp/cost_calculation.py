import pandas as pd

if __name__ == "__main__":
    df = pd.read_csv("tmp/openrouter_activity_2025-11-08.csv")
    print(df.columns)
    df = df.query("created_at > '2025-11-08 16:29:34.640'")
    print(len(df))
    res = df.groupby("model_permaslug").cost_total.sum()
    print(res)
