def main():
    print("Hello from infinite-zork!")


if __name__ == "__main__":
    main()
