# TODO list

- [x] Room fixture generation
- [x] Room item generation (treasure only)
- [x] Basic parser
- [x] Web UI v0
- [x] Tie Game engine to content
- [x] Tie UI&Parser to Game Engine
- [ ] Better interactables (iterative?)
- [ ] Item generation (functional)
- [ ] Puzzle generation (w/actions)
- [ ] Interactible hyperlinking
- [ ] Image generation