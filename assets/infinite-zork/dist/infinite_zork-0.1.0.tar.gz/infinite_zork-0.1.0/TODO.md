# TODO list


## First release
### Game
- [x] Help
- [x] Track #items
- [x] Remove or fill in exits and items
- [x] Add fixed score per treasure
- [ ] Congratulate player on max score
- [ ] Generate final content with treasure
### Visual
- [x] Center the console
- [x] Clean up
- [x] ~~Remove extra room title~~
- [x] Render markdown
### Procgen
- [x] Carve out alias generation
- [x] Carve out object detection
- [x] Ensure max. objects
- [x] Record discarded/decorative objects
- [x] Enrich vocabulary
- [x] Rule-based deduplication
- [x] Fix item generation

## General
- [x] Room fixture generation
- [x] Room item generation (treasure only)
- [x] Basic parser
- [x] Web UI v0
- [x] Tie Game engine to content
- [x] Tie UI&Parser to Game Engine
- [ ] Better interactables (iterative?)
- [ ] Item generation (functional)
- [ ] Puzzle generation (w/actions)
- [ ] Interactable hyperlinking
- [ ] Image generation