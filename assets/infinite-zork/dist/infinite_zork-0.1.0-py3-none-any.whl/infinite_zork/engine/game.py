import logging

from infinite_zork.engine import parser
from infinite_zork.engine.action_handlers import handle_action
from infinite_zork.engine.parser import ParseError
from infinite_zork.shared.models import GameState, Player, GameInput, GameOutput


def initialize(path):
    with open(path) as f:
        state = GameState.model_validate_json(f.read())

    player = Player(
        score=0,
        current_room_id=state.start_room_id,
    )
    state.player = player

    return state


def handle_input(
    state: GameState, game_input: GameInput
) -> tuple[GameOutput, GameState]:
    try:
        action = parser.parse(game_input.text, state)
    except ParseError as e:
        output = GameOutput(text=e.args[0])
    else:
        logging.debug(f"Action: {action}, Input: {game_input.text}")

        output, state = handle_action(state, action)

    return output, state


def game_loop(state):
    while True:
        game_input = yield
        if game_input is None:
            continue
        output, state = handle_input(state, game_input)
        yield output, state


def main():
    state = initialize(".output/full_map.json")
    loop = game_loop(state)
    next(loop)
    while True:
        input_raw = input("> ")
        game_input = GameInput(text=input_raw)
        output, state = loop.send(game_input)
        next(loop)
        print(output.text)


if __name__ == "__main__":
    logging.basicConfig(level=logging.DEBUG)
    main()
