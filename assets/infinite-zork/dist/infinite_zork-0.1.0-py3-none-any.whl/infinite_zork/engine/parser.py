import dataclasses
from enum import StrEnum

from infinite_zork.shared.models import GameState

DIRECTION_KEYWORDS = ["north", "south", "east", "west", "up", "down"]


class ActionId(StrEnum):
    move = "move"
    look = "look"
    examine = "examine"
    get = "get"
    drop = "drop"
    use = "use"
    open = "open"
    close = "close"
    inventory = "inventory"


class TargetScope(StrEnum):
    """Defines where to look for action targets"""

    INVENTORY = "inventory"
    ROOM = "room"
    BOTH = "both"


ACTIONS_WITHOUT_TARGET = {ActionId.look, ActionId.inventory}
ACTIONS_WITH_TARGET = set(ActionId) - set(ACTIONS_WITHOUT_TARGET)

# Map actions to their target scope
ACTION_TARGET_SCOPE = {
    ActionId.drop: TargetScope.INVENTORY,
    ActionId.get: TargetScope.ROOM,
    ActionId.examine: TargetScope.BOTH,
    ActionId.use: TargetScope.BOTH,
    ActionId.open: TargetScope.BOTH,
    ActionId.close: TargetScope.BOTH,
    ActionId.move: TargetScope.ROOM,  # Not really used, special case
}

ALIAS_MAP = {
    "go": "move",
    "look at": "look",
    "x": "examine",
    "l": "look",
    "n": "north",
    "s": "south",
    "e": "east",
    "w": "west",
    "i": "inventory",
}


@dataclasses.dataclass
class Target:
    aliases: list[str]
    id: str


def get_inventory_targets(state: GameState) -> list[Target]:
    """Get all targets in the player's inventory"""
    # Will implement later, focus on parser first
    return []


def get_room_targets(state: GameState) -> list[Target]:
    """Get all targets in the current room"""
    # Will implement later, focus on parser first
    objects = state.interactable_objects
    return [Target(o.aliases, o.id) for o in objects]


@dataclasses.dataclass
class Action:
    id: ActionId
    target: str | None = None
    kwargs: dict | None = None


class ParseError(Exception):
    """Base exception for parsing errors"""

    pass


class MissingTargetError(ParseError):
    """Raised when an action requires a target but none was provided"""

    def __init__(self, action_id: ActionId):
        self.action_id = action_id
        super().__init__(f"What do you want to {action_id}?")


class TargetNotFoundError(ParseError):
    """Raised when the specified target doesn't exist in the game state"""

    def __init__(self, target_name: str):
        self.target_name = target_name
        super().__init__(f"I don't see '{target_name}' here.")


class AmbiguousTargetError(ParseError):
    """Raised when multiple targets match the given name"""

    def __init__(self, target_name: str, matches: list[Target]):
        self.target_name = target_name
        self.matches = matches
        match_names = [match.aliases[0] for match in matches]
        super().__init__(f"Which do you mean: {', or '.join(match_names)}?")


def _find_matching_targets(
    target_name: str, available_targets: list[Target]
) -> list[Target]:
    """
    Find all targets that match the given name.

    Args:
        target_name: The name to search for
        available_targets: List of targets to search through

    Returns:
        List of matching Target objects
    """
    matches = []
    for target in available_targets:
        if target_name in target.aliases:
            matches.append(target)
    return matches


def _get_targets_for_scope(scope: TargetScope, state: GameState) -> list[Target]:
    """
    Get targets based on the specified scope.

    Args:
        scope: Where to look for targets
        state: Current game state

    Returns:
        List of targets in the specified scope
    """
    match scope:
        case TargetScope.INVENTORY:
            return get_inventory_targets(state)
        case TargetScope.ROOM:
            return get_room_targets(state)
        case TargetScope.BOTH:
            return get_inventory_targets(state) + get_room_targets(state)


def parse(command: str, state: GameState) -> Action:
    """
    Parse a text adventure command into an Action.

    Args:
        command: The user's input string
        state: Current game state for context-aware parsing

    Returns:
        An Action object if parsing succeeds

    Raises:
        MissingTargetError: When action requires a target but none provided
        TargetNotFoundError: When specified target doesn't exist in the appropriate scope
        AmbiguousTargetError: When multiple targets match the given name
        ParseError: When command cannot be parsed
    """
    # Normalize: lowercase and strip whitespace
    command = command.strip().lower()

    if not command:
        raise ParseError("Please enter a command.")

    # Apply aliases
    for alias, replacement in ALIAS_MAP.items():
        if command == alias or command.startswith(alias + " "):
            command = command.replace(alias, replacement, 1)

    # Split into tokens
    tokens = command.split()

    if not tokens:
        raise ParseError("Please enter a command.")

    action_word = tokens[0]

    # Try to match against known actions
    match action_word:
        case str(a) if a in ActionId.__members__:
            action_id = ActionId(a)

            # Handle actions without targets
            if action_id in ACTIONS_WITHOUT_TARGET:
                return Action(id=action_id, target=None)

            # Handle actions with targets
            elif action_id in ACTIONS_WITH_TARGET:
                if len(tokens) < 2:
                    # No target provided
                    raise MissingTargetError(action_id)

                target_name = " ".join(tokens[1:])

                # Handle special case for directional movement
                if action_id == ActionId.move and target_name in DIRECTION_KEYWORDS:
                    return Action(id=action_id, target=target_name)

                # Get the appropriate scope for this action
                scope = ACTION_TARGET_SCOPE.get(action_id, TargetScope.BOTH)

                # Find targets in the appropriate scope
                available_targets = _get_targets_for_scope(scope, state)
                matching_targets = _find_matching_targets(
                    target_name, available_targets
                )

                if not matching_targets:
                    raise TargetNotFoundError(target_name)

                if len(matching_targets) > 1:
                    raise AmbiguousTargetError(target_name, matching_targets)

                # We have exactly one match - return it!
                matched_target = matching_targets[0]
                return Action(id=action_id, target=matched_target.id)

        case _:
            # Check if the first word might be a direction (for implicit "move")
            if action_word in DIRECTION_KEYWORDS:
                return Action(id=ActionId.move, target=action_word)

            raise ParseError(f"I don't understand '{action_word}'.")

    raise ParseError("I don't understand that command.")


if __name__ == "__main__":
    while True:
        command = input("> ")
        try:
            action = parse(command, None)
        except ParseError as e:
            print(e.args[0])
        else:
            if action:
                print(action)
