from infinite_zork.engine.parser import ActionId
from infinite_zork.shared.models import (
    GameState,
    Action,
    Room,
    Outcome,
    OutcomeType,
    RoomItemPlacement,
    GameOutput,
)


def handle_action(state: GameState, action: Action) -> tuple[GameOutput, GameState]:
    """
    Handle user input: parse, execute action, update state, and generate output.

    Args:
        state: Current game state
        game_input: User's input command

    Returns:
        Tuple of (GameOutput with response text, updated GameState)
    """

    # Get current room for convenience
    current_room = state.rooms.get(state.player.current_room_id)

    # Execute the action
    match action.id:
        case ActionId.look:
            output_text = _handle_look(state, current_room)

        case ActionId.inventory:
            output_text = _handle_inventory(state)

        case ActionId.move:
            output_text, state = _handle_move(state, current_room, action.target)

        case ActionId.examine:
            output_text = _handle_examine(state, current_room, action.target)

        case ActionId.get:
            output_text, state = _handle_get(state, current_room, action.target)

        case ActionId.drop:
            output_text, state = _handle_drop(state, current_room, action.target)

        case ActionId.use:
            output_text, state = _handle_use(state, current_room, action.target)

        case ActionId.open:
            output_text = _handle_open(state, current_room, action.target)

        case ActionId.close:
            output_text = _handle_close(state, current_room, action.target)

        case _:
            output_text = "That action is not yet implemented."

    return GameOutput(text=output_text), state


def _handle_look(state: GameState, room: Room) -> str:
    """Generate a full room description."""
    lines = [f"**{room.title}**", "", room.description]

    # List visible items
    visible_items = [
        item_placement
        for item_placement in room.items
        if item_placement.location == "room"
    ]

    if visible_items:
        lines.append("")
        for item_placement in visible_items:
            lines.append(item_placement.description)

    # List exits
    if room.exits:
        lines.append("")
        exit_directions = [exit.direction for exit in room.exits if exit.allowed]
        if exit_directions:
            lines.append(f"Exits: {', '.join(exit_directions)}")

    return "\n".join(lines)


def _handle_inventory(state: GameState) -> str:
    """List items in player's inventory."""
    if not state.player.inventory:
        return "You are empty-handed."

    items_list = [item.short_name for item in state.player.inventory]
    return "You are carrying:\n" + "\n".join(f"  {item}" for item in items_list)


def _handle_move(state: GameState, room: Room, direction: str) -> tuple[str, GameState]:
    """Handle player movement."""
    exit_obj = room.exit_map.get(direction)

    if not exit_obj:
        return f"You can't go {direction} from here.", state

    if not exit_obj.allowed:
        return exit_obj.description, state

    # Update player's current room
    state.player.current_room_id = exit_obj.room_id

    # Return look description of new room
    new_room = state.rooms[exit_obj.room_id]
    return _handle_look(state, new_room), state


def _handle_examine(state: GameState, room: Room, target_id: str) -> str:
    """Examine an item or fixture."""
    # Check inventory
    for item in state.player.inventory:
        if item.id == target_id:
            return item.description

    # Check room items
    for item_placement in room.items:
        item = state.items.get(item_placement.item_id)
        if item and item.id == target_id:
            return item.description

    # Check fixtures
    for fixture in room.fixtures:
        if fixture.id == target_id:
            desc = fixture.description
            # If it's a container, list contents
            if fixture.container:
                container_items = [
                    state.items[ip.item_id].short_name
                    for ip in room.items
                    if ip.location == fixture.id
                ]
                if container_items:
                    desc += f"\n\nInside you see: {', '.join(container_items)}"
                else:
                    desc += "\n\nIt is empty."
            return desc

    return "You don't see anything special about that."


def _handle_get(state: GameState, room: Room, target_id: str) -> tuple[str, GameState]:
    """Pick up an item."""
    # Find the item placement in the room
    for item_placement in room.items:
        item = state.items.get(item_placement.item_id)
        if item and item.id == target_id:
            # Check if item is accessible (in room or in an open container)
            if item_placement.location != "room":
                # Item is in a fixture - for now, assume it's accessible
                # (We'd check if container is open in a more complete implementation)
                pass

            # Add to inventory
            state.player.inventory.append(item)

            # Remove from room by marking it as taken (not removing from list)
            # We'll filter it out when displaying
            item_placement.location = state.player.id

            return "Taken.", state

    return "You can't take that.", state


def _handle_drop(state: GameState, room: Room, target_id: str) -> tuple[str, GameState]:
    """Drop an item from inventory."""
    # Find item in inventory
    for i, item in enumerate(state.player.inventory):
        if item.id == target_id:
            # Remove from inventory
            state.player.inventory.pop(i)

            # Find or create item placement in room
            item_placement = None
            for ip in room.items:
                if ip.item_id == item.id:
                    item_placement = ip
                    break

            if item_placement:
                # Item was originally from this room
                item_placement.location = "room"
            else:
                # Item is new to this room, create placement
                new_placement = RoomItemPlacement(
                    item_id=item.id,
                    description=f"There is a {item.short_name} here.",
                    location="room",
                )
                room.items.append(new_placement)

            return "Dropped.", state

    return "You don't have that.", state


def _handle_use(state: GameState, room: Room, target_id: str) -> tuple[str, GameState]:
    """Use an item or interact with a fixture."""
    # Check if there's a custom action defined for this target
    for action in room.actions:
        # This is simplified - you'd want better syntax matching
        if target_id in action.syntax.lower():
            output_text, state = _execute_action_outcome(state, room, action.outcome)
            return output_text, state

    # Default response
    return "You're not sure how to use that.", state


def _handle_open(state: GameState, room: Room, target_id: str) -> str:
    """Open a container or door."""
    for fixture in room.fixtures:
        if fixture.id == target_id:
            if fixture.container:
                return f"You open the {fixture.short_name}."
            else:
                return "You can't open that."

    return "I don't see that here."


def _handle_close(state: GameState, room: Room, target_id: str) -> str:
    """Close a container or door."""
    for fixture in room.fixtures:
        if fixture.id == target_id:
            if fixture.container:
                return f"You close the {fixture.short_name}."
            else:
                return "You can't close that."

    return "I don't see that here."


def _execute_action_outcome(
    state: GameState, room: Room, outcome: Outcome
) -> tuple[str, GameState]:
    """Execute an action outcome and return result text."""
    match outcome.type:
        case OutcomeType.set_flag:
            flag_name = outcome.args[0]
            room.flags.add(flag_name)
            return "Done.", state

        case OutcomeType.create_item:
            item_id, location = outcome.args
            # Logic to create/reveal item would go here
            return "Something happened.", state

        case OutcomeType.change_desc:
            flag_name, new_desc = outcome.args
            room.flags.add(flag_name)
            room.base_description = new_desc
            return new_desc, state

        case _:
            return "Something strange happened.", state
